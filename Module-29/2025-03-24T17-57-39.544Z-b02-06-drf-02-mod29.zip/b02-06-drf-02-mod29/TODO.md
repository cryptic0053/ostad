1. Token Authentication with JWT ✅
2. Permission Classes ✅
3. Filtering Data ✅
4. Searching ✅
5. Ordering ✅
6. Pagination ✅
7. Throttling / Rate Limiting ✅
