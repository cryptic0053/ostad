from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.permissions import AllowAny

from django_filters.rest_framework import DjangoFilterBackend

from .models import Contact, Author, Book
from .serializers import ContactSerializer, AuthorSerializer, BookSerializer


from rest_framework import permissions


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Custom permission to only allow owners of an object to edit it.
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed for any request
        if request.method in permissions.SAFE_METHODS:
            return True

        # Write permissions are only allowed to the owner
        return obj.user == request.user


# View Level Configuration
class ContactViewSet(viewsets.ModelViewSet):
    queryset = Contact.objects.all()
    serializer_class = ContactSerializer
    permission_classes = [AllowAny]


class AuthorViewSet(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer


# from django_filters import FilterSet, NumberFilter


# class BookFilter(FilterSet):
#     min_price = NumberFilter(field_name="price", lookup_expr="gte")
#     max_price = NumberFilter(field_name="price", lookup_expr="lte")

#     class Meta:
#         models = Book
#         fields = ["min_price", "max_price"]

from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.pagination import PageNumberPagination


class MyGhorardimPagination(PageNumberPagination):
    page_size = 10


class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

    permission_classes = [AllowAny]

    filter_backends = [
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    ]

    #
    # filter_backends = [DjangoFilterBackend]
    filterset_fields = ["author", "title"]
    # filterset_class = BookFilter

    #
    # filter_backends = [SearchFilter]
    search_fields = ["title"]

    #
    # filter_backends = [OrderingFilter]
    orderding_fields = ["title", "author"]

    #
    pagination_class = MyGhorardimPagination
